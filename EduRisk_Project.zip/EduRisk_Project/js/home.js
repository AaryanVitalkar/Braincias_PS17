// js/home.js
function goNext() {
    window.location.href = "predict.html";
}

window.goNext = goNext;
