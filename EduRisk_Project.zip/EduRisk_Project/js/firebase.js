// js/firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCHpZM5cmw2MwwWFMa3SWpLx34Ailg_QtQ",
  authDomain: "edurisk-app-b4b1f.firebaseapp.com",
  projectId: "edurisk-app-b4b1f",
  databaseURL: "https://edurisk-app-b4b1f-default-rtdb.firebaseio.com/",
  storageBucket: "edurisk-app-b4b1f.firebasestorage.app",
  messagingSenderId: "854252140078",
  appId: "1:854252140078:web:bbc6a666315c7ea63011bf"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
