import { db } from "./firebase.js";
import { ref, push } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

// Chart instances
let attChartInstance = null;
let skillChartInstance = null;

function goHome() {
    window.location.href = "index.html";
}

async function predictRisk() {
    const studentData = {
        attendance: Number(document.getElementById("attendance").value),
        marks: Number(document.getElementById("marks").value),
        backlogs: Number(document.getElementById("backlogs").value),
        hours: Number(document.getElementById("study_hours").value),
        failures: Number(document.getElementById("failures").value),
        year: Number(document.getElementById("year").value),
        skills: Number(document.getElementById("skill_level").value)
    };

    const resultDiv = document.getElementById("result");
    const graphSection = document.getElementById("graph-section");
    const adviceBox = document.getElementById("advice-box");

    // UI Loading State
    resultDiv.style.display = "block";
    resultDiv.innerHTML = "⏳ AI is analyzing...";
    resultDiv.className = "result";
    graphSection.style.display = "none";
    adviceBox.style.display = "none";

    try {
        const response = await fetch('http://127.0.0.1:5000/predict_risk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(studentData)
        });

        const apiResult = await response.json();

        if (apiResult.status === "success") {
            const riskLevel = apiResult.risk_level;
            const confidence = apiResult.confidence_score;

            // 1. Show Risk Level
            const cssClass = riskLevel.split(" ")[0]; 
            resultDiv.className = "result " + cssClass;
            resultDiv.innerHTML = `
                <h3>${riskLevel.toUpperCase()}</h3>
                <p>AI Confidence: ${confidence}%</p>
            `;

            // 2. Render Charts
            graphSection.style.display = "grid";
            renderCharts(studentData);

            // 3. Render Advice
            renderAdvice(apiResult.advice);

            // 4. Save to Firebase
            saveToFirebase(studentData, riskLevel, confidence);

        } else {
            resultDiv.innerHTML = "⚠️ API Error: " + apiResult.message;
        }

    } catch (error) {
        console.error("Connection Error:", error);
        resultDiv.innerHTML = "❌ Connection Failed! Ensure 'api.py' is running.";
    }
}

// --- Helper: Draw Charts ---
function renderCharts(data) {
    const ctxAtt = document.getElementById('attChart').getContext('2d');
    const ctxSkill = document.getElementById('skillChart').getContext('2d');

    if (attChartInstance) attChartInstance.destroy();
    if (skillChartInstance) skillChartInstance.destroy();

    // Attendance Graph
    attChartInstance = new Chart(ctxAtt, {
        type: 'bar',
        data: {
            labels: ['Your Attendance', 'Safe Limit (75%)'],
            datasets: [{
                label: 'Attendance %',
                data: [data.attendance, 75],
                backgroundColor: [data.attendance < 75 ? '#ff4b4b' : '#36a2eb', '#4bc0c0']
            }]
        },
        options: {
            responsive: true,
            plugins: { title: { display: true, text: 'Attendance Check' } },
            scales: { y: { beginAtZero: true, max: 100 } }
        }
    });

    // Skill Graph
    const requiredSkill = data.year * 2;
    skillChartInstance = new Chart(ctxSkill, {
        type: 'bar',
        data: {
            labels: ['Your Skill', `Year ${data.year} Goal`],
            datasets: [{
                label: 'Skill Level',
                data: [data.skills, requiredSkill],
                backgroundColor: [data.skills < requiredSkill ? '#ffcd56' : '#36a2eb', '#9966ff']
            }]
        },
        options: {
            responsive: true,
            plugins: { title: { display: true, text: 'Skill Analysis' } },
            scales: { y: { beginAtZero: true, max: 10 } }
        }
    });
}

// --- Helper: Render Advice ---
function renderAdvice(adviceArray) {
    const adviceList = document.getElementById("advice-list");
    const adviceBox = document.getElementById("advice-box");
    
    adviceList.innerHTML = ""; // Clear old
    adviceArray.forEach(tip => {
        const li = document.createElement("li");
        li.innerHTML = tip;
        adviceList.appendChild(li);
    });
    
    adviceBox.style.display = "block";
}

function saveToFirebase(data, risk, confidence) {
    const fullRecord = {
        ...data,
        student_id: document.getElementById("student_id").value || "Unknown",
        college: document.getElementById("college_name").value || "Unknown",
        predicted_risk: risk,
        confidence_score: confidence,
        timestamp: new Date().toISOString()
    };

    const studentsRef = ref(db, "students");
    push(studentsRef, fullRecord)
        .then(() => console.log("✅ Saved to Firebase"))
        .catch((err) => console.error("Firebase Error:", err));
}

window.predictRisk = predictRisk;
window.goHome = goHome;