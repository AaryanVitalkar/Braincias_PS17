from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np
import os

app = Flask(__name__)
CORS(app)

# Load Model
if os.path.exists('risk_model.pkl'):
    try:
        model = joblib.load('risk_model.pkl')
        print("✅ Model loaded successfully!")
    except:
        model = None
else:
    print("❌ 'risk_model.pkl' not found. Please run train_model.py first.")
    model = None

@app.route('/predict_risk', methods=['POST'])
def predict():
    if not model:
        return jsonify({"status": "error", "message": "Model not loaded on server"})

    try:
        data = request.json
        print(f"📩 Input: {data}")

        # 1. Extract Features
        attendance = float(data.get('attendance', 0))
        marks = float(data.get('marks', 0))
        backlogs = int(data.get('backlogs', 0))
        hours = float(data.get('hours', 0))
        failures = int(data.get('failures', 0))
        year = int(data.get('year', 1))
        skills = int(data.get('skills', 1))

        features = [attendance, marks, backlogs, hours, failures, year, skills]

        # 2. Predict Risk
        input_vector = np.array([features])
        prediction = model.predict(input_vector)[0]
        confidence = float(model.predict_proba(input_vector).max())

        # 3. Generate Smart Advice
        advice_list = []
        
        # Attendance Logic
        if attendance < 75:
            gap = 75 - attendance
            advice_list.append(f"📉 **Attendance Warning:** You are lagging by {gap}%. Attend the next few classes to recover.")
        
        # Skill Logic
        required_skill = year * 2
        if skills < required_skill:
            advice_list.append(f"🛠️ **Skill Gap:** For Year {year}, the industry expects Level {required_skill}. Try building a small project.")

        # Academic Logic
        if marks < 60:
            advice_list.append("📚 **Academics:** Your average marks are below 60%. Focus on upcoming internals.")
        
        # Backlog Logic
        if backlogs > 0:
            advice_list.append(f"⚠️ **Backlogs:** You have {backlogs} active backlogs. Prioritize clearing these.")

        if not advice_list:
            advice_list.append("🌟 **Excellent Work:** Your profile is balanced. Keep maintaining this consistency!")

        # 4. Return Response
        return jsonify({
            "status": "success",
            "risk_level": prediction,
            "confidence_score": round(confidence * 100, 2),
            "advice": advice_list
        })

    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    print("🚀 Flask API running on http://127.0.0.1:5000")
    app.run(port=5000, debug=True)